#ifdef __CONCREST__
#include "../../assert.h"
#include "crest.h"
#else
#include <assert.h>
#endif
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#ifndef __CONCREST__
#define CREST_shared_int(x)
#endif

#define assume(x) if (!(x)) { CREST_scope_begin(); printf("Violated assumption at line %d\n", __LINE__); CREST_scope_end(); exit(0); }

#define MEMORY_NULL -1

// CREST_int(x);
// CREST_shared_int(x);

/* WARNING: we are ignoring the ABA problem! */

// handling of random

//int CONCREST_RANDOM_index;
//static pthread_mutex_t RANDOM_LOCK;

#define NUMBER_OF_THREADS_TOTAL 3
pthread_t logical_thread_id[NUMBER_OF_THREADS_TOTAL];
#define NUMBER_OF_RANDOM_VALUES_PER_THREAD 4
int CONCREST_RANDOM_VALUES[NUMBER_OF_RANDOM_VALUES_PER_THREAD * NUMBER_OF_THREADS_TOTAL];
int THREAD_LOCAL_RANDOM_COUNTER[NUMBER_OF_THREADS_TOTAL];





void init_CONCREST_RANDOM(int range) {
#ifdef __CONCREST__
	int i;
	CREST_var_int(i, CREST_LOCAL_VAR, "i");
	CREST_var_int(range, CREST_LOCAL_VAR, "range");

	for (i = 0; i < NUMBER_OF_THREADS_TOTAL; i++) {
		CREST_scope_begin();
		logical_thread_id[i] = 0;
		THREAD_LOCAL_RANDOM_COUNTER[i] = 0;
		CREST_scope_end();
	}

	for (i = 0; i < NUMBER_OF_RANDOM_VALUES_PER_THREAD * NUMBER_OF_THREADS_TOTAL; i++) {
		CREST_scope_begin();
		CREST_int((CONCREST_RANDOM_VALUES[i]));

		printf("Assigning random value rand[%d] = %d\n", i, CONCREST_RANDOM_VALUES[i]);

		assume(CONCREST_RANDOM_VALUES[i] >= 0);
		assume(CONCREST_RANDOM_VALUES[i] < range);
		CREST_scope_end();
	}
#endif
}

int CONCREST_RANDOM(int range) {
#ifdef __CONCREST__
	int i;

	int offset;

	CREST_var_int(i, CREST_LOCAL_VAR, "i");
	CREST_var_int(offset, CREST_LOCAL_VAR, "offset");
	CREST_var_int(range, CREST_LOCAL_VAR, "range");

	offset = -1;

	for (i = 0; i < NUMBER_OF_THREADS_TOTAL; i++) {
		CREST_scope_begin();
		pthread_t self = pthread_self();
		if (logical_thread_id[i] == self) {
			CREST_scope_begin();
			if (THREAD_LOCAL_RANDOM_COUNTER[i] < NUMBER_OF_RANDOM_VALUES_PER_THREAD) {
				CREST_scope_begin();
				offset = i * NUMBER_OF_RANDOM_VALUES_PER_THREAD + THREAD_LOCAL_RANDOM_COUNTER[i];
				THREAD_LOCAL_RANDOM_COUNTER[i]++;
				CREST_scope_end();
				break;
			}
			else {
				CREST_scope_begin();
				printf("WE DO NOT HAVE ENOUGH RANDOM VALUES!\n"); // TODO how to communicate that nicely? internal error flag?
				CREST_scope_end();
				exit(0);
			}
			CREST_scope_end();
		}
		CREST_scope_end();
	}

	assume(offset >= 0);

	int value;
	CREST_var_int(value, CREST_LOCAL_VAR, "value");

	value = CONCREST_RANDOM_VALUES[offset];

	return value;

#if 0
	pthread_mutex_lock(&RANDOM_LOCK);

	int index;

	CREST_var_int(index, CREST_LOCAL_VAR, "index");
	index = CONCREST_RANDOM_index;

	CONCREST_RANDOM_index++;

	pthread_mutex_unlock(&RANDOM_LOCK);

	for (i = 0; i < NUMBER_OF_RANDOM_VALUES; i++) {
		CREST_scope_begin();
		if (i == index) {
			CREST_scope_begin();
			int value;
			value = CONCREST_RANDOM_VALUES[i];
			CREST_scope_end();
			return value;
		}
		CREST_scope_end();
	}

	printf("WE DO NOT HAVE ENOUGH RANDOM VALUES!\n"); // TODO how to communicate that nicely? internal error flag?
	exit(0);
#endif
#else
	return (random()%range);
#endif
}

/* treiber stack data structures */

#define NUMBER_OF_TREIBER_STACKS 2
/*

NODE_MEMORY_top replaces

typedef struct __ts_t {
	int top;
} ts_t;

*/
int TS_top[NUMBER_OF_TREIBER_STACKS];


/*

NODE_MEMORY_next and NODE_MEMORY_data replace

typedef struct __ts_node_t {
	int next;
	uint64_t data;
} ts_node_t;

*/
#define NODES_PER_THREAD 2
#define NUMBER_OF_NODES_IN_HEAP (NODES_PER_THREAD * NUMBER_OF_THREADS_TOTAL)
int NODE_MEMORY_next[NUMBER_OF_NODES_IN_HEAP];
uint64_t NODE_MEMORY_data[NUMBER_OF_NODES_IN_HEAP];
//unsigned NODE_MEMORY_INDEX = 0;
int THREAD_LOCAL_MEMORY_COUNTER[NUMBER_OF_THREADS_TOTAL];

//static pthread_mutex_t NODE_MEMORY_LOCK;

int alloc_ts_node_t() {
	int i;

	int offset;

	CREST_var_int(i, CREST_LOCAL_VAR, "i");
	CREST_var_int(offset, CREST_LOCAL_VAR, "offset");

	offset = -1;
	for (i = 0; i < NUMBER_OF_THREADS_TOTAL; i++) {
		CREST_scope_begin();
		pthread_t self = pthread_self();
		if (logical_thread_id[i] == self) {
			CREST_scope_begin();
			if (THREAD_LOCAL_MEMORY_COUNTER[i] < NODES_PER_THREAD) {
				CREST_scope_begin();
				offset = i * NODES_PER_THREAD + THREAD_LOCAL_MEMORY_COUNTER[i];
				THREAD_LOCAL_MEMORY_COUNTER[i]++;
				CREST_scope_end();
				break;
			}
			else {
				CREST_scope_begin();
				printf("WE DO NOT HAVE ENOUGH HEAP!\n"); // TODO how to communicate that nicely? internal error flag?
				CREST_scope_end();
				exit(0);
			}
			CREST_scope_end();
		}
		CREST_scope_end();
	}

	assume(offset >= 0);

	return offset;

#if 0
	pthread_mutex_lock(&NODE_MEMORY_LOCK);

	int tmp;
	CREST_var_int(tmp, CREST_LOCAL_VAR, "tmp");
	tmp = NODE_MEMORY_INDEX;

	if (tmp >= NUMBER_OF_NODES_IN_HEAP) {
		CREST_scope_begin();
		printf("MEMORY MANAGEMENT RAN OUT OF MEMORY! (ts_node_t)\n");
		CREST_scope_end();
		exit(EXIT_FAILURE);
	}

	NODE_MEMORY_INDEX = tmp + 1;

	pthread_mutex_unlock(&NODE_MEMORY_LOCK);

	return tmp;
#endif
}

void initialize_pool() {
	unsigned i;
	CREST_var_unsigned_int(i, CREST_LOCAL_VAR, "i");

	for (i = 0; i < NUMBER_OF_THREADS_TOTAL; i++) {
		CREST_scope_begin();
		THREAD_LOCAL_MEMORY_COUNTER[i] = 0;
		CREST_scope_end();
	}

	//CREST_shared_int(NODE_MEMORY_INDEX);

	for (i = 0; i < NUMBER_OF_TREIBER_STACKS; i++) {
		CREST_scope_begin();
		CREST_shared_int((TS_top[i]));
		TS_top[i] = MEMORY_NULL;
		CREST_scope_end();
	}

	for (i = 0; i < NUMBER_OF_NODES_IN_HEAP; i++) {
		//CREST_scope_begin();
		CREST_shared_int((NODE_MEMORY_data[i]));
		//NODE_MEMORY_data[i] = 0;
		CREST_shared_int((NODE_MEMORY_next[i]));
		//NODE_MEMORY_next[i] = MEMORY_NULL;
		//CREST_scope_end();
	}
}

void write_data(int index, uint64_t value) {
	int i;

	CREST_var_int(i, CREST_LOCAL_VAR, "i");

	for (i = 0; i < NUMBER_OF_NODES_IN_HEAP; i++) {
		CREST_scope_begin();
		if (index == i) {
			CREST_scope_begin();
			NODE_MEMORY_data[i] = value;
			CREST_scope_end();
			//return;
		}
		CREST_scope_end();
	}

	// TODO actually we should have assertions here, but for initial testing we aim for semantic assertions
	//printf("OUT OF BOUNDS ACCESS!"); // TODO how shall we communicate this? internal error flag?
	//exit(0);
	//assert(0); // out of bounds access !
}

void write_next(int index, int value) {
	int i;
	CREST_var_int(i, CREST_LOCAL_VAR, "i");

	for (i = 0; i < NUMBER_OF_NODES_IN_HEAP; i++) {
		CREST_scope_begin();
		if (index == i) {
			CREST_scope_begin();
			NODE_MEMORY_next[i] = value;
			//return;
			CREST_scope_end();
		}
		CREST_scope_end();
	}

	// TODO actually we should have assertions here, but for initial testing we aim for semantic assertions
	//printf("OUT OF BOUNDS ACCESS!"); // TODO how shall we communicate this? internal error flag?
	//exit(0);
	//assert(0); // out of bounds access !
}

int read_top(int index) {
	int i;
	int value;
	CREST_var_int(i, CREST_LOCAL_VAR, "i");
	CREST_var_int(value, CREST_LOCAL_VAR, "value");
	CREST_var_int(index, CREST_LOCAL_VAR, "index");

	value = MEMORY_NULL;

	for (i = 0; i < NUMBER_OF_TREIBER_STACKS; i++) {
		CREST_scope_begin();
		if (index == i) {
			CREST_scope_begin();
			value = TS_top[i];
			CREST_scope_end();
			//return value;
		}
		CREST_scope_end();
	}

	return value;

	// TODO actually we should have assertions here, but for initial testing we aim for semantic assertions
	//printf("OUT OF BOUNDS ACCESS!"); // TODO how shall we communicate this? internal error flag?
	//exit(0);
	//assert(0); // out of bounds access !
}

void write_top(int index, int value) {
	int i;

	CREST_var_int(i, CREST_LOCAL_VAR, "i");
	CREST_var_int(value, CREST_LOCAL_VAR, "value");
	CREST_var_int(index, CREST_LOCAL_VAR, "index");

	for (i = 0; i < NUMBER_OF_TREIBER_STACKS; i++) {
		CREST_scope_begin();
		if (i == index) {
			CREST_scope_begin();
			TS_top[i] = value;
			//return;
			CREST_scope_end();
		}
		CREST_scope_end();
	}

	// TODO actually we should have assertions here, but for initial testing we aim for semantic assertions
	//printf("OUT OF BOUNDS ACCESS!"); // TODO how shall we communicate this? internal error flag?
	//exit(0);
	//assert(0); // out of bounds access !
}

int read_next(int index) {
	int i;
	int value;

	CREST_var_int(i, CREST_LOCAL_VAR, "i");
	CREST_var_int(value, CREST_LOCAL_VAR, "value");
	CREST_var_int(index, CREST_LOCAL_VAR, "index");

	value = MEMORY_NULL;
	for (i = 0; i < NUMBER_OF_NODES_IN_HEAP; i++) {
		CREST_scope_begin();
		if (index == i) {
			CREST_scope_begin();
			value = NODE_MEMORY_next[i];
			//return value;
			CREST_scope_end();
		}
		CREST_scope_end();
	}

	return value;

	// TODO actually we should have assertions here, but for initial testing we aim for semantic assertions
	//printf("OUT OF BOUNDS ACCESS!"); // TODO how shall we communicate this? internal error flag?
	//exit(0);
	//assert(0); // out of bounds access !
}

uint64_t read_data(int index) {
	int i;

	uint64_t value;

	CREST_var_int(i, CREST_LOCAL_VAR, "i");
	CREST_var_unsigned_int(value, CREST_LOCAL_VAR, "value");
	CREST_var_int(index, CREST_LOCAL_VAR, "index");

	value = 0;

	for (i = 0; i < NUMBER_OF_NODES_IN_HEAP; i++) {
		CREST_scope_begin();
		if (index == i) {
			CREST_scope_begin();
			//uint64_t value;
			value = NODE_MEMORY_data[i];
			//return value;
			CREST_scope_end();
		}
		CREST_scope_end();
	}

	return value;

	// TODO actually we should have assertions here, but for initial testing we aim for semantic assertions
	//printf("OUT OF BOUNDS ACCESS!"); // TODO how shall we communicate this? internal error flag?
	//exit(0);
	//assert(0); // out of bounds access !
}

static pthread_mutex_t cas_mutex;

inline int CAS(int* old, int expectedval, int newval) {
	int result;

	CREST_var_int(result, CREST_LOCAL_VAR, "result");
	CREST_var_int(expectedval, CREST_LOCAL_VAR, "expectedval");
	CREST_var_int(newval, CREST_LOCAL_VAR, "newval");
	CREST_var_int(old, CREST_LOCAL_VAR, "old");

	result = 0;

	pthread_mutex_lock(&cas_mutex);
	if (*old == expectedval) {
		CREST_scope_begin();
		*old = newval;
		result = 1;
		CREST_scope_end();
	}
	pthread_mutex_unlock(&cas_mutex);

	return result;
}

inline int CAS_top(int TS_index, int expectedval, int newval) {
	int result;

	CREST_var_int(result, CREST_LOCAL_VAR, "result");
	CREST_var_int(expectedval, CREST_LOCAL_VAR, "expectedval");
	CREST_var_int(newval, CREST_LOCAL_VAR, "newval");
	CREST_var_int(TS_index, CREST_LOCAL_VAR, "TS_index");

	result = 0;

	pthread_mutex_lock(&cas_mutex);

	int old_value = read_top(TS_index);

	if (old_value == expectedval) {
		CREST_scope_begin();
		//*old = newval;
		write_top(TS_index, newval);
		result = 1;
		CREST_scope_end();
	}
	pthread_mutex_unlock(&cas_mutex);

	return result;
}

void ts_push(uint64_t item) {
	//assert(item != 0);
	CREST_var_unsigned_int(item, CREST_LOCAL_VAR, "item");

	assume(item != 0); // TODO can we define a specification language that enables us to turn assertions into assumptions?

	int node_index;
	CREST_var_int(node_index, CREST_LOCAL_VAR, "node_index");
	node_index = alloc_ts_node_t();

	//NODE_MEMORY_data[node_index] = item;
	write_data(node_index, item);

	int top_old_index;
	int top_new_index;
	unsigned index;

	CREST_var_int(node_index, CREST_LOCAL_VAR, "node_index");
	CREST_var_int(top_old_index, CREST_LOCAL_VAR, "top_old_index");
	CREST_var_int(top_new_index, CREST_LOCAL_VAR, "top_new_index");
	CREST_var_unsigned_int(index, CREST_LOCAL_VAR, "index");

	index = CONCREST_RANDOM(NUMBER_OF_TREIBER_STACKS);

	/*do { //Mitra
		//top_old_index = TS_top[index];
		top_old_index = read_top(index);
		top_new_index = node_index;

		//NODE_MEMORY_next[node_index] = top_old_index;
		write_next(node_index, top_old_index);
	}
	//while (CAS(&(TS_top[index]), top_old_index, top_new_index) == 0);
	while (!CAS_top(index, top_old_index, top_new_index));*/ //Mitra

	//Mitra
	//top_old_index = TS_top[index];
	top_old_index = read_top(index);
	top_new_index = node_index;

	//NODE_MEMORY_next[node_index] = top_old_index;
	write_next(node_index, top_old_index);
	while (!CAS_top(index, top_old_index, top_new_index))
	{
		CREST_scope_begin();
		//top_old_index = TS_top[index];
		top_old_index = read_top(index);
		top_new_index = node_index;

		//NODE_MEMORY_next[node_index] = top_old_index;
		write_next(node_index, top_old_index);
		CREST_scope_end();
	}
	//end Mitra
}

uint64_t ts_pop() {
	int top_old_index;
	int top_new_index;

	CREST_var_int(top_old_index, CREST_LOCAL_VAR, "top_old_index");
	CREST_var_int(top_new_index, CREST_LOCAL_VAR, "top_new_index");


	unsigned index;
	CREST_var_unsigned_int(index, CREST_LOCAL_VAR, "index");
	index = CONCREST_RANDOM(NUMBER_OF_TREIBER_STACKS);

	uint64_t result;
	unsigned i;

	CREST_var_unsigned_int(result, CREST_LOCAL_VAR, "result");
	CREST_var_unsigned_int(i, CREST_LOCAL_VAR, "i");


	for (i = 0; i < NUMBER_OF_TREIBER_STACKS; i++) {
		CREST_scope_begin();
		int tmp_index;
		CREST_var_int(tmp_index, CREST_LOCAL_VAR, "tmp_index");

		if (index + i >= NUMBER_OF_TREIBER_STACKS) {
			CREST_scope_begin();
			tmp_index = index + i - NUMBER_OF_TREIBER_STACKS;
			CREST_scope_end();
		}
		else {
			CREST_scope_begin();
			tmp_index = index + i;
			CREST_scope_end();
		}
		//int tmp_index = ((index + i)%NUMBER_OF_TREIBER_STACKS);

		/*do { //Mitra
			//top_old_index = TS_top[tmp_index];
			top_old_index = read_top(tmp_index);

			if (top_old_index == MEMORY_NULL) {
				result = 0;
				break;
			}
			else {
				//top_new_index = NODE_MEMORY_next[top_old_index];
				top_new_index = read_next(top_old_index);

				//if (CAS(&(TS_top[tmp_index]), top_old_index, top_new_index)) {
				if (CAS_top(tmp_index, top_old_index, top_new_index)) {
					//result = NODE_MEMORY_data[top_old_index];
					result = read_data(top_old_index);
					break;
				}
			}

		} while (1);*/ //Mitra

		//Mitra
		while (1) {
			CREST_scope_begin();
			//top_old_index = TS_top[tmp_index];
			top_old_index = read_top(tmp_index);

			if (top_old_index == MEMORY_NULL) {
				CREST_scope_begin();
				result = 0;
				CREST_scope_end();
				break;
			}
			else {
				CREST_scope_begin();
				//top_new_index = NODE_MEMORY_next[top_old_index];
				top_new_index = read_next(top_old_index);

				//if (CAS(&(TS_top[tmp_index]), top_old_index, top_new_index)) {
				if (CAS_top(tmp_index, top_old_index, top_new_index)) {
					CREST_scope_begin();
					//result = NODE_MEMORY_data[top_old_index];
					result = read_data(top_old_index);
					CREST_scope_end();
					break;
				}
				CREST_scope_end();
			}
			CREST_scope_end();
		}

		if (result != 0) {
			break;
		}
		CREST_scope_end();
	}

	return result;
}

// 2 threads should be able to trigger the bug without using a loop in the thread function body.
/*
  ERROR DESCRIPTION:

  T1: push(1)
  T1:   index = 1
  T1:   ts[index]->push(1)

  T2: push(2)
  T2:   index = 0
  T2:   ts[index]->push(2)

  T1: pop()
  T1:   index = 0

  T2: pop()
  T2:   index = 0
  T2:   ts[index]->pop() ... 2

  T1:   ts[0]->pop() ... 0
  T1:   index = 1

  T2: push(2)
  T2:   index = 0
  T2:   ts[0]->push(2)
  T2: pop()
  T2:   index = 1
  T2:   ts[1]->pop() ... 1

  T1:   ts[1]->pop() ... 0
  T1:   return 0
 */

void* thread_func(void* data) {
	int value;
	CREST_var_int(value, CREST_LOCAL_VAR, "value");
	value = (int)data;

	logical_thread_id[value] = pthread_self(); // TODO the tool has to do this internally

	// do something
	printf("hi from %u\n", value);

	ts_push(value);

	uint64_t x;
	CREST_var_unsigned_int(x, CREST_LOCAL_VAR, "x");
	x = ts_pop();

	printf("thread %d popped value %d from stack\n", value, x);

	assert(x != 0);

	printf("bye from %u\n", value);

	pthread_exit(NULL);
	return NULL;
}

void* thread_func2(void* data) {
	int value;
	CREST_var_int(value, CREST_LOCAL_VAR, "value");
	value = (int)data;

	logical_thread_id[value] = pthread_self(); // TODO the tool has to do this internally

	// do something
	printf("hi from %u\n", value);

	ts_push(value);

	uint64_t x;
	CREST_var_unsigned_int(x, CREST_LOCAL_VAR, "x");
	x = ts_pop();
	printf("thread %d popped value %d from stack\n", value, x);

	ts_push(value);

	x = ts_pop();
	printf("thread %d popped value %d from stack\n", value, x);

	printf("bye from %u\n", value);

	pthread_exit(NULL);
	return NULL;
}

int main(int argc, char **argv) {

	int m;
	CREST_var_int(m, CREST_LOCAL_VAR, "m");

	char str[30];
	char mi[3];
	for (m = 0; m < NUMBER_OF_RANDOM_VALUES_PER_THREAD * NUMBER_OF_THREADS_TOTAL; m++) {
		strcpy(str, "CONCREST_RANDOM_VALUES_");
		strcpy(mi, "");
		sprintf(mi, "%d", m);
		strcat(str, mi);
		CREST_var_int(CONCREST_RANDOM_VALUES[m], CREST_SHARED_VAR, str);
	}

	for (m = 0; m < NUMBER_OF_THREADS_TOTAL; m++) {
		strcpy(str, "THREAD_LOCAL_RANDOM_COUNTER_");
		strcpy(mi, "");
		sprintf(mi, "%d", m);
		strcat(str, mi);
		CREST_var_int(THREAD_LOCAL_RANDOM_COUNTER[m], CREST_SHARED_VAR, str);
	}

	for (m = 0; m < NUMBER_OF_TREIBER_STACKS; m++) {
		strcpy(str, "TS_top_");
		strcpy(mi, "");
		sprintf(mi, "%d", m);
		strcat(str, mi);
		CREST_var_int(TS_top[m], CREST_SHARED_VAR, str);
	}

	for (m = 0; m < NUMBER_OF_NODES_IN_HEAP; m++) {
		strcpy(str, "NODE_MEMORY_next_");
		strcpy(mi, "");
		sprintf(mi, "%d", m);
		strcat(str, mi);
		CREST_var_int(NODE_MEMORY_next[m], CREST_SHARED_VAR, str);
	}

	for (m = 0; m < NUMBER_OF_NODES_IN_HEAP; m++) {
		strcpy(str, "NODE_MEMORY_data_");
		strcpy(mi, "");
		sprintf(mi, "%d", m);
		strcat(str, mi);
		CREST_var_unsigned_int(NODE_MEMORY_data[m], CREST_SHARED_VAR, str);
	}

	for (m = 0; m < NUMBER_OF_THREADS_TOTAL; m++) {
		strcpy(str, "THREAD_LOCAL_MEMORY_COUNTER_");
		strcpy(mi, "");
		sprintf(mi, "%d", m);
		strcat(str, mi);
		CREST_var_unsigned_int(THREAD_LOCAL_MEMORY_COUNTER[m], CREST_SHARED_VAR, str);
	}

	init_CONCREST_RANDOM(NUMBER_OF_TREIBER_STACKS);

	logical_thread_id[0] = pthread_self();

	printf("initializing pthreads ...\n");

	int i;
	CREST_var_int(i, CREST_LOCAL_VAR, "i");
	pthread_t some_threads[NUMBER_OF_THREADS_TOTAL - 1];

	pthread_mutex_init(&(cas_mutex), NULL);
#ifdef __CONCREST__
	//pthread_mutex_init(&(RANDOM_LOCK), NULL);
	//pthread_mutex_init(&(NODE_MEMORY_LOCK), NULL);
#endif

	printf("initializing data structure ...\n");
	initialize_pool();

	printf("spawning threads ...\n");

	/*for (i = 0; i < kNumThreads; i++) {
		pthread_create(&some_threads[i], NULL, thread_func, (void*)(i + 1));
	}*/
	pthread_create(&some_threads[0], NULL, thread_func, (void*)1);
	pthread_create(&some_threads[1], NULL, thread_func2, (void*)2);

	pthread_exit(NULL);
	return EXIT_SUCCESS;
}


